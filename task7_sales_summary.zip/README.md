# Task 7: Sales Summary using SQLite and Python

## Objective
Use Python and SQLite to summarize sales data and visualize revenue per product.

## Tools Used
- Python
- SQLite (`sqlite3`)
- pandas
- matplotlib

## Steps
1. Created a SQLite database `sales_data.db` with sample sales data.
2. Queried total quantity and revenue using SQL.
3. Loaded the result into a pandas DataFrame.
4. Printed the result and visualized it using a bar chart (`sales_chart.png`).

## How to Run
```bash
python sales_summary.py
```

## Output
- Sales summary printed in terminal.
- Bar chart saved as `sales_chart.png`.
